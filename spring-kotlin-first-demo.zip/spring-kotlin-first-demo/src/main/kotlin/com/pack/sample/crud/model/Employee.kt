package com.pack.sample.crud.model

import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id
import javax.persistence.Entity
import javax.persistence.Table

@Entity
@Table

data class Employee(
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    val eid:Int = 0,
   // @get: NotBlank
    val ename: String = "",
    //@get : NotBlank
    val dept:String= "")