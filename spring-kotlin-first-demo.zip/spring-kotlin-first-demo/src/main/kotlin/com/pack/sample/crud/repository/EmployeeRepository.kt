package com.pack.sample.crud.repository

import com.pack.sample.crud.model.Employee
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.data.jpa.repository.config.EnableJpaRepositories
import org.springframework.stereotype.Repository

@Repository
@EnableJpaRepositories
interface EmployeeRepository : JpaRepository<Employee,Integer> {
    fun findByName(name:String): Employee
     fun deleteById(id: Int)

}