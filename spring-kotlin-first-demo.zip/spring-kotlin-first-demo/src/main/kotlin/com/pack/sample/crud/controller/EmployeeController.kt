package com.pack.sample.crud.controller

import com.pack.sample.crud.model.Employee
import com.pack.sample.crud.repository.EmployeeRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Qualifier
import org.springframework.web.bind.annotation.*


@RestController
@RequestMapping("/employees")
class EmployeeController {

    @Autowired
    @Qualifier("employeeRepository")

    lateinit var employeeRepository:EmployeeRepository;

    @PostMapping("/saveemp")
    fun save(@RequestBody employee: Employee): String
    {
        employeeRepository.save(employee)
        return "Employee saved successfully..."

    }


    @GetMapping("/getemployees")
    fun getEmployee():List<Employee>
    {
        return employeeRepository.findAll()
    }
    @GetMapping("/getemployee/{name}")
    fun getEmployee(@PathVariable name:String):Employee{

        return employeeRepository.findByName(name);
    }
}
