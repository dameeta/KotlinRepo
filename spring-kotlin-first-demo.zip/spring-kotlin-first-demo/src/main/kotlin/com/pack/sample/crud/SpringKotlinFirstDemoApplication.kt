package com.pack.sample.crud

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication

open class SpringKotlinFirstDemoApplication

fun main(args: Array<String>) {
	runApplication<SpringKotlinFirstDemoApplication>(*args)
}
